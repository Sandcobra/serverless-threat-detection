import boto3, json, os

sns = boto3.client("sns")
SUSPICIOUS_EVENTS = ["CreateAccessKey", "AttachUserPolicy", "DeleteUser"]

def lambda_handler(event, context):
    for record in event['Records']:
        payload = json.loads(record['body'])
        message = json.loads(payload['Message'])
        event_name = message.get("eventName")
        user_identity = message.get("userIdentity", {}).get("userName", "Unknown")

        if event_name in SUSPICIOUS_EVENTS:
            alert = {
                "event": event_name,
                "user": user_identity,
                "timestamp": message.get("eventTime"),
                "region": message.get("awsRegion")
            }
            sns.publish(
                TopicArn=os.environ["SNS_TOPIC_ARN"],
                Message=json.dumps(alert),
                Subject="🚨 Suspicious IAM Activity Detected"
            )